public final class FurutechPlug implements UKPlugConnector {
    public void provideElectricity()
    {
        System.out.println("providing electricity to a Furutech plug.");
    }
}