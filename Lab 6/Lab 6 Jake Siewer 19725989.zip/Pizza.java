
public interface Pizza {

	public String getDesc();
	public double getPrice();
}
